#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

class StudentWorld;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class Actor : public GraphObject{
public:
    Actor(StudentWorld* world, int imageID, double startX, double startY, int startDir = -1):
        GraphObject(imageID, startX, startY, startDir), m_world(world) {};
    StudentWorld* getWorld();
    virtual void doSomething() = 0;
    int getHp();
    void setHp(int change);
    bool isAlive();
    void setAlive(bool set);
private:
    StudentWorld* m_world;
    int m_hp;
    bool m_alive;
};

//Avatar
class Avatar : public Actor{
public:
    Avatar(StudentWorld* world, double startX, double startY)
        : Actor(world, IID_PLAYER, startX, startY, 0){
        setVisible(true);
        setAlive(true);
        setHp(20);
        m_peas = 20;
    }
;
    virtual void doSomething();
private:
    int m_peas;
};

//Walls
class Wall : public Actor{
public:
    Wall(StudentWorld* world, double level_x, double level_y)
        : Actor(world, IID_WALL, level_x, level_y){
        setVisible(true);
        setHp(0);
        setAlive(false);
    };
    virtual void doSomething();
};

#endif // ACTOR_H_
