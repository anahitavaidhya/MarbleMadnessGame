#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

StudentWorld* Actor::getWorld(){
    return m_world;
}

int Actor :: getHp(){
    return m_hp;
}
void Actor :: setHp(int change){
     m_hp += change;
}
bool Actor :: isAlive(){
    return m_alive;
}
void Actor :: setAlive(bool set){
    m_alive = set;
}

void Avatar::doSomething(){
    if(!isAlive()){
        return;
    } else {
        int ch;
        if (getWorld()->getKey(ch))
        {
            // user hit a key this tick!
            switch (ch){
                case KEY_PRESS_LEFT:
                    if(!getWorld()->isWall(getX()-1, getY())){
                        setDirection(180);
                        moveTo(getX() - 1, getY());
                    }
                    break;
                case KEY_PRESS_RIGHT:
                    if(!getWorld()->isWall(getX()+1, getY())){
                        setDirection(0);
                        moveTo(getX() + 1, getY());
                    }
                    break;
                case KEY_PRESS_UP:
                    if(!getWorld()->isWall(getX(), getY()+1)){
                        setDirection(90);
                        moveTo(getX(), getY()+1);
                    }
                    break;
                case KEY_PRESS_DOWN:
                    if(!getWorld()->isWall(getX(), getY()-1)){
                        setDirection(270);
                        moveTo(getX(), getY()-1);
                    }
                    break;
            }
        }
    }
}
    
void Wall::doSomething(){}
