#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

class StudentWorld;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class Actor : public GraphObject{
public:
    Actor(StudentWorld* world, int imageID, double startX, double startY, int dir = -1);
    StudentWorld* getWorld();
    virtual void doSomething() = 0;
    int getHp();
    void setHp(int change);
    bool isAlive();
    void setAlive(bool set);
private:
    StudentWorld* m_world;
    int m_hp;
    bool m_alive;
};

//Avatar
class Avatar : public Actor{
public:
    Avatar(StudentWorld* world, double startX, double startY);
    virtual void doSomething();
private:
    int m_peas;
};

//Walls
class Wall : public Actor{
public:
    Wall(StudentWorld* world, double level_x, double level_y);
    virtual void doSomething();
};

#endif // ACTOR_H_
