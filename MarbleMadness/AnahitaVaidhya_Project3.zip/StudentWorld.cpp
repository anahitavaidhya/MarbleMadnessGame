#include "StudentWorld.h"
#include "GameConstants.h"
//#include "Actor.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{}

StudentWorld::~StudentWorld(){
    cleanUp();
}

int StudentWorld::init()
{
    //Check if vector is empty
    if (!m_actors.empty())
        m_actors.clear();
    
    //Get Level
    Level lev(assetPath());
    string levelFile = "";
    if(getLevel() < 10)
        levelFile = "level0" + to_string(getLevel()) + ".txt";
    else
        levelFile = "level" + to_string(getLevel()) + ".txt";
    
    Level::LoadResult result = lev.loadLevel(levelFile);
    
    //Check Level
    if (result == Level::load_fail_file_not_found || getLevel() == 100){
        cerr << "Could not find " << levelFile << ".txt data file\n";
        return GWSTATUS_PLAYER_WON;
    } else if (result == Level::load_fail_bad_format){
        cerr << "Your level was improperly formatted\n";
        return GWSTATUS_LEVEL_ERROR;
    } else if (result == Level::load_success)
    {
        cerr << "Successfully loaded level\n";
        Level::MazeEntry loc;
        //Push players into vector
        for(int x = 0; x < VIEW_WIDTH; x++){
            for(int y = 0; y < VIEW_HEIGHT; y++){
                loc = lev.getContentsOf(x, y);
                if(loc == Level::player){
                    m_avatar = new Avatar(this, x, y);
                } else if(loc == Level::wall){
                    m_actors.push_back(new Wall(this, x, y));
                }
            }
        }
    }
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you type q
    setGameStatText("Game will end when you type q");
        
    //Avatar doSomething
    m_avatar->doSomething();
    
    // Each actor doSomething
    std::vector<Actor*>::iterator it;
    it = m_actors.begin();
    while (it != m_actors.end()) {
        (*it)->doSomething();
        it++;
    }
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    if (m_actors.end() == m_actors.begin()) return; // empty vector
        //Delete every actor
        std::vector<Actor*>::iterator it;
        it = m_actors.end();
        it--;
        while (it != m_actors.begin()) {
            std::vector<Actor*>::iterator it2;
            it2 = it;
            it2--;
            delete *it;
            m_actors.erase(it);
            it = it2;
        }
        delete *it;
        m_actors.erase(it);
}

bool StudentWorld::isWall(double x, double y) {
    //Check if it is a Wall
    std::vector<Actor*>::iterator it;
    it = m_actors.begin();
    while (it != m_actors.end()) {
        if ((*it)->getX() == x && (*it)->getY() == y) {
            return true;
        }
        it++;
    }
    return false;
}

